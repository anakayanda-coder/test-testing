# CBE Timetable Management System – Version 1

Stack:
- Python
- FastAPI
- SQLAlchemy
- PostgreSQL
- Jinja2
- OR-Tools (prepared for Version 2)
- Render

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000

The default local database is SQLite. On Render, DATABASE_URL connects the application to PostgreSQL.

## Deploy to Render

1. Create a GitHub repository.
2. Upload this project.
3. In Render choose New > Blueprint.
4. Select the GitHub repository.
5. Render reads `render.yaml` and creates the web service and PostgreSQL database.
6. Deploy.

## Version 2

Add:
- Academic years and semesters
- Programmes and student groups
- Excel import
- Course/lecturer/group allocation
- Time slots
- Lecturer availability
- Room availability
- Clash detection
- OR-Tools CP-SAT timetable generation
- PDF and Excel export
- User authentication and role-based access
