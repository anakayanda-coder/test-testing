import os
from fastapi import FastAPI, Request, Depends, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, Column, Integer, String, ForeignKey, Time
from sqlalchemy.orm import declarative_base, sessionmaker, Session, relationship

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./timetable.db")
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

class Department(Base):
    __tablename__ = "departments"
    id = Column(Integer, primary_key=True)
    name = Column(String(150), nullable=False)
    code = Column(String(30), unique=True, nullable=False)

class Programme(Base):
    __tablename__ = "programmes"
    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False)
    code = Column(String(50), unique=True, nullable=False)
    department_id = Column(Integer, ForeignKey("departments.id"), nullable=True)
    department = relationship("Department")

class Lecturer(Base):
    __tablename__ = "lecturers"
    id = Column(Integer, primary_key=True)
    name = Column(String(150), nullable=False)
    staff_no = Column(String(50), unique=True, nullable=False)

class Course(Base):
    __tablename__ = "courses"
    id = Column(Integer, primary_key=True)
    code = Column(String(50), unique=True, nullable=False)
    name = Column(String(200), nullable=False)
    credits = Column(Integer, default=1)

class StudentGroup(Base):
    __tablename__ = "student_groups"
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    programme_id = Column(Integer, ForeignKey("programmes.id"), nullable=True)
    programme = relationship("Programme")

class Room(Base):
    __tablename__ = "rooms"
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    capacity = Column(Integer, nullable=False, default=30)

class TimeSlot(Base):
    __tablename__ = "time_slots"
    id = Column(Integer, primary_key=True)
    day = Column(String(20), nullable=False)
    start_time = Column(Time, nullable=False)
    end_time = Column(Time, nullable=False)

class TimetableEntry(Base):
    __tablename__ = "timetable_entries"
    id = Column(Integer, primary_key=True)
    course_id = Column(Integer, ForeignKey("courses.id"), nullable=False)
    lecturer_id = Column(Integer, ForeignKey("lecturers.id"), nullable=False)
    group_id = Column(Integer, ForeignKey("student_groups.id"), nullable=False)
    room_id = Column(Integer, ForeignKey("rooms.id"), nullable=False)
    slot_id = Column(Integer, ForeignKey("time_slots.id"), nullable=False)
    course = relationship("Course")
    lecturer = relationship("Lecturer")
    group = relationship("StudentGroup")
    room = relationship("Room")
    slot = relationship("TimeSlot")

Base.metadata.create_all(bind=engine)

app = FastAPI(title="CBE Timetable System")
templates = Jinja2Templates(directory="app/templates")

def db():
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()

@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request, session: Session = Depends(db)):
    data = {
        "departments": session.query(Department).count(),
        "programmes": session.query(Programme).count(),
        "courses": session.query(Course).count(),
        "lecturers": session.query(Lecturer).count(),
        "groups": session.query(StudentGroup).count(),
        "rooms": session.query(Room).count(),
        "entries": session.query(TimetableEntry).count(),
    }
    return templates.TemplateResponse("dashboard.html", {"request": request, "data": data})

@app.get("/courses", response_class=HTMLResponse)
def courses(request: Request, session: Session = Depends(db)):
    return templates.TemplateResponse("courses.html", {
        "request": request, "courses": session.query(Course).order_by(Course.code).all()
    })

@app.post("/courses")
def add_course(code: str = Form(...), name: str = Form(...), credits: int = Form(1),
               session: Session = Depends(db)):
    session.add(Course(code=code.strip(), name=name.strip(), credits=credits))
    session.commit()
    return RedirectResponse("/courses", status_code=303)

@app.get("/lecturers", response_class=HTMLResponse)
def lecturers(request: Request, session: Session = Depends(db)):
    return templates.TemplateResponse("lecturers.html", {
        "request": request, "lecturers": session.query(Lecturer).order_by(Lecturer.name).all()
    })

@app.post("/lecturers")
def add_lecturer(name: str = Form(...), staff_no: str = Form(...),
                 session: Session = Depends(db)):
    session.add(Lecturer(name=name.strip(), staff_no=staff_no.strip()))
    session.commit()
    return RedirectResponse("/lecturers", status_code=303)

@app.get("/rooms", response_class=HTMLResponse)
def rooms(request: Request, session: Session = Depends(db)):
    return templates.TemplateResponse("rooms.html", {
        "request": request, "rooms": session.query(Room).order_by(Room.name).all()
    })

@app.post("/rooms")
def add_room(name: str = Form(...), capacity: int = Form(...),
             session: Session = Depends(db)):
    session.add(Room(name=name.strip(), capacity=capacity))
    session.commit()
    return RedirectResponse("/rooms", status_code=303)

@app.get("/departments", response_class=HTMLResponse)
def departments(request: Request, session: Session = Depends(db)):
    return templates.TemplateResponse("departments.html", {
        "request": request, "departments": session.query(Department).order_by(Department.name).all()
    })

@app.post("/departments")
def add_department(name: str = Form(...), code: str = Form(...),
                    session: Session = Depends(db)):
    session.add(Department(name=name.strip(), code=code.strip()))
    session.commit()
    return RedirectResponse("/departments", status_code=303)

@app.get("/timetable", response_class=HTMLResponse)
def timetable(request: Request, session: Session = Depends(db)):
    entries = session.query(TimetableEntry).all()
    return templates.TemplateResponse("timetable.html", {"request": request, "entries": entries})

@app.get("/health")
def health():
    return {"status": "ok"}
