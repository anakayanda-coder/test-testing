# Initial database entities

departments
programmes
courses
lecturers
student_groups
rooms
time_slots
timetable_entries

The schema is intentionally small for Version 1. Version 2 should introduce
academic years, semesters, course allocations, availability rules and timetable
versions before implementing the CP-SAT solver.
